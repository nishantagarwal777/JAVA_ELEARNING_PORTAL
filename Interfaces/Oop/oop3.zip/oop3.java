class MathsSquareDemo1 {
	  
			void  calculate(double price){
			System.out.println(�Sqare value �+(price*price));
			}
		}
		
		classMathsSquareDemo2  extends MathsSquareDemo1 {
		
			void calculate(double price){
			System.out.println(�Sqare value �+(Math.sqrt(price)));
			}
		}
		
		public class MethodOverriddingDemo{
		
			public static void main (String arg[]){
				MathsSquareDemo2 msd=new MathsSquareDemo2();
				msd.calculate(25);
			}
		}
