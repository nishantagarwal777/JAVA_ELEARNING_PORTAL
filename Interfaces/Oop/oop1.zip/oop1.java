class StudentInfo {
	  
	  String  name;
	  int rollno;
	  
	  int  get(String n, int r){
	  	name=n; 
		rollno=r; 
		return(0);
		}
		
		void showDetails(){
		System.out.println(�Name : �+name);
		}

	  
	  }

	class InheritanceExampleDemo extends StudentInfo {
		public static void main(String args[]){
		StudentInfo studObj = new StudentInfo();
		studObj.get(�Eswar�,92);
		studObj.showDetails();
		}

	  }
	  
		


