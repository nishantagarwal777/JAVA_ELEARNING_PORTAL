class Subjects {
	
		void add(int tamil, int english){
		System.out.println(�The total of tamil and english is �+(tamil+english));
			}
		void add(int tamil,int english,int maths){
		System.out.println(�The total of tamil english and maths is �+(tamil+english+maths));
			}
	}


	class MethodOverloadingDemo { 
	public static void main(String args[]){
		Subjects sb=new Subjects();	 //create Subjects class object
		
		sb.add(90, 80); // we have to call add() method by passing 2 values
		
		sb.add(95,85,100); //here also we are calling add() method by passing 3 values, 
		                                So the 3 arguments (parameters) method will get execute.
							  
		}
	} 