 class Bike{
   Bike()
   {
   		System.out.println("Bike is created");
   }
   public static void main( String  args[]) {
   		Bike b=new Bike();
	
    }
	}