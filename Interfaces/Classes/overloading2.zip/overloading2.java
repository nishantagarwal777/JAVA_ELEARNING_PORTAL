class Simple{
	  void sum(int a,int b){
  		System.out.println (a+b);
		}
		
		void sum(double a,double b){
		System.out.println (a+b);
	  }
	  
	   
	  public static void main(String args[]){
	  
	  	Simple ob1=new Simple();
		ob1.sum(10.5,1.9); 
		ob1.sum(20,60);
		
		}
	}	