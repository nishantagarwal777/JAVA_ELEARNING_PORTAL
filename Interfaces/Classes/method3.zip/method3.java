class Simple{
	  public long factorial (int n) {
  		if (n < 0) {
       return -1;
      } 
      else if (n == 0) {
      return 1;
      }
      else {
      return n*factorial(n-1);
    }
 
   }       

  public class Demo{
  
	  public static void main(String args[]){
	  
	  	Simple ob1=new Simple();
		int larger;
		larger=ob1.factorial(5); 
		
		}
		}	