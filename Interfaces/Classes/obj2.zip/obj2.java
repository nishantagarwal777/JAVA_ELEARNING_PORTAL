class Simple{
	 int i;
	 float j;     
   }
	 
   class Demo{
   	public static void  main(String args[]){
		
		Simple o1;//It creates an object reference of type Simple pointing to null.
		
		o1=new Simple();//It creates an object of type Simple and 
					   //returns its reference which is stored in o1.
					   
		Simple o2=o1;//o2 is made to point to the object pointed by o1.
					  
		Simple o1=null;//Now o1 is pointing to null. 
	}
   }