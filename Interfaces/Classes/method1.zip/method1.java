class Simple{
	  public int max(int num1,int num2){
  		int result;
		if(num1>num2)
			result=num1;
		else 
			result=num2;
		
		return result;
		
	  }
	  public class Demo{
  
	  public static void main(String args[]){
	  
	  	Simple ob1=new Simple();
		int larger;
		larger=ob1.max(30,40); //max method of class Simple 
						    accessed via object ob1 returns a value of type 
						    integer,which is stored in the variable larger.
		System.out.println(larger);
		
		}	 