class Simple{
	  int sum(int a,int b){
  		System.out.println (a+b);
		}
		
		double sum(int a,int b){
		System.out.println (a+b);
	  }
	  
	   
	  public static void main(String args[]){
	  
	  	Simple ob1=new Simple();
		int result = ob1.sum(20,20);//Compile time error.
				 	     		   //How can Java detemine which 
					                 //sum() method to call..
 
		
		}
	}	 