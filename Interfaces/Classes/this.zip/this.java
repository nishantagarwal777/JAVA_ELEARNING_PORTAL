Class A {
   
   A getA() {
   
	  return this;
	  
	}
	
	void msg() { 
	
	System.out.println (�Hello java�); 
	
	}
}
	
	Class Test {
	
	public static void main ( String args[])  {
		new A().getA().msg();
		}
	}
	