public class Puppy{
	  public Puppy(String name){
  		
  		System.out.println("Passed Name is :" + name );  
	  } 
	  public static void main(String args[]){
		
		Puppy myPuppy = new Puppy( "tommy" );//Object reference myPuppy pointing to 
										//an object of type Puppy is created.
  	  }
  }