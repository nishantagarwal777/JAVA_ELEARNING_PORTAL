 class Simple{
	  public double max(double num1, double num2){
  		double result;
		if(num1>num2)
			result=num1;
		else 
			result=num2;
		
		return result;
	  }
	  
	   public int max(int num1, int num2){
  		int result1;
		if(num1>num2)
			result=num1;
		else 
			result=num2;
		
		return result1;
	   }
	   
	  }

  public class Demo{
  
	  public static void main(String args[]){
	  
	  	Simple ob1=new Simple();
		int larger;
		double larger2;
		larger=ob1.max(30,40); //It calls the method which take integer as parameter.
		System.out.println(larger);
		larger2=ob1.max(10.2,4.2); //It calls the method which take double as parameter.
		System.out.println(larger2);
		
		}	 