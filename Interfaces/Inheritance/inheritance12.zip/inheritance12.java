public abstract class Employee {
   			private String  name;
			private String  address;
			private int  number;
			public abstract double  computePay();
   
         
        }
		
		public class Salary extends Employee {
			private double  salary;  // Annual salary :  
			public double computePay()
   			{
      			System.out.println("Computing salary pay for " + getName());
      			return salary/52;
   			}

   //Remainder of class definition
}
