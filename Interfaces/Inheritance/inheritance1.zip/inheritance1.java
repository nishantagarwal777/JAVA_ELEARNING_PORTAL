class Employee{
	  int sal=4500;
  	}
		
	class Programmer extends Employee{
		int bonus=10000;
	  
	   public static void main(String args[]){
	  
	  	Programmer p=new Programmer();
		System.out.println(�Programmer's salary :�+p.sal);
		System.out.println(�Programmer's bonus :�+p.bonus);
		
		}
	}	