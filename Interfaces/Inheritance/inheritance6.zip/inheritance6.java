class Person{
   		void message() {
		System.out.println ( � Welcome�);
        }
		
	}
   
	class Student extends Person{
         void message() {
		System.out.println ( � Welcome to java �);
        }
		 void display(){
		 message(); // will invoke current class message() method 
		 super.message(); // will invoke parent class message() method 
		 }
		  
		public static void main ( String agrs[] ){
		Student s = new Student();
		s.display();
	    }
    }