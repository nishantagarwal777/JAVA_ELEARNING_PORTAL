class Bike{ 
   			final void run() {
			System.out.println (�Bike is running��!!);
			}
   }
   		class Honda extends  Bike { 
			void run() {
			System.out.println ("Running safely�!!);
			}
	  public static void main ( String agrs[] ){
	      Honda h1=new Honda();
	     h1.run();

	  }
}