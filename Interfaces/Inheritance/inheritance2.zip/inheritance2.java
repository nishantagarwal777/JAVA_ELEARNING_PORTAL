class A{
	  void msg(){
  		System.out.println ("Hello...!!);
		}
		
	  class B{
		void msg(){
  		System.out.println ("Welcome...!!);
		}
	  
	   class C extends A,B{ //Suppose it were there 
	  public static void main(String args[]){
	  
	  	C ob1=new C();
		ob1.msg();//How can Java detemine which 
				//msg() method to call..
 
				
		}
	}	 