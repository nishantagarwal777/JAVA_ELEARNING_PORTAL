class Vehicle{ 
   		int speed = 50;
     }
   
	class Bike extends Vehicle{
          int speed = 100;
		  
		  void display() {
		  System.out.println(super.speed); // will print speed of vehicle
		  }
		  
	  public static void main ( String agrs[] ){
	      Bike b=new Bike();
	      b.display();

	  }
}

	