class Bike{ 
   			final int speed = 90;
			void run() {
			speed=400;
			}
   
	  public static void main ( String agrs[] ){
	      Bike obj1=new Bike();
	     obj1.run();

	  }
}