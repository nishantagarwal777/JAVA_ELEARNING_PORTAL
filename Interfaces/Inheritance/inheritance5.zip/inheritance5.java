class Vehicle{ 
   		Vehicle() {
		System.out.println ( � Vehicle is created �);
        }
		
	}
   
	class Bike extends Vehicle{
         Bike() {
		 super(); // will invoke parent class constructor. 
		 System.out.println ( � Bike is created � );
		 }
		  
		public static void main ( String agrs[] ){
		Bike b=new Bike();
	    }
    }