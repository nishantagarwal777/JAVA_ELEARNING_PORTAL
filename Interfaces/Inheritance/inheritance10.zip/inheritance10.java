public abstract class Bike {
		int limit=30;
			Bike() {
				System.out.println("Constructor is invoked"); }
			
		void getDetails() {
				System.out.println(" It has two wheels...");  }
			
		abstract void run();
	}


	public class Honda extends Bike {
		void run(){
		System.out.println(" Running...");    }
			
				
		public static void main(String args[]){
			Honda b1=new Honda();
			b1.run();
			b1.getDetails();
			System.out.println(b1.limit);
			
			}
	}
