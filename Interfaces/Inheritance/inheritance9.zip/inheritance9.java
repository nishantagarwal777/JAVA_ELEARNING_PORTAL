final class Bike{ 
   		}
   		class Honda extends  Bike { 
			void run() {
			System.out.println ("Running safely�!!);
			}
	  public static void main ( String agrs[] ){
	      Honda h1=new Honda();
	     h1.run();

	  }
}