class Bike{ 
			abstract void run(); // will give compiler error..  
		}
		